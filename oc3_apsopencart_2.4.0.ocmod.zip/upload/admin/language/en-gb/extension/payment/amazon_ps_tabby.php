<?php
$_['heading_title'] = '<span id="amazon_ps_tabby">Amazon Payment Services </span><script>$("#extension #amazon_ps_tabby").closest("tr").remove();</script>';