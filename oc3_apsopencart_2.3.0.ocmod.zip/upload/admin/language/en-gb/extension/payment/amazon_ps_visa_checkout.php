<?php
$_['heading_title'] = '<span id="amazon_ps_visa_checkout">Amazon Payment Services </span><script>$("#extension #amazon_ps_visa_checkout").closest("tr").remove();</script>';
