<?php
$_['heading_title'] = '<span id="amazon_ps_naps">Amazon Payment Services </span><script>$("#extension #amazon_ps_naps").closest("tr").remove();</script>';