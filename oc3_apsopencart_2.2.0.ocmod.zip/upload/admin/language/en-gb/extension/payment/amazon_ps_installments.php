<?php
$_['heading_title'] = '<span id="amazon_ps_installments">Amazon Payment Services </span><script>$("#extension #amazon_ps_installments").closest("tr").remove();</script>';